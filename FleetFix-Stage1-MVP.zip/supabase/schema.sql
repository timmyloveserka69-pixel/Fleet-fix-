create extension if not exists pgcrypto;
create type user_role as enum ('owner','manager','driver','technician','admin');
create type ticket_status as enum ('open','assigned','in_progress','waiting_parts','completed','cancelled');

create table fleets(id uuid primary key default gen_random_uuid(), name text not null, created_at timestamptz not null default now());
create table profiles(id uuid primary key references auth.users(id) on delete cascade, fleet_id uuid references fleets(id) on delete cascade, full_name text, role user_role not null default 'driver', created_at timestamptz not null default now());
create table vehicles(id uuid primary key default gen_random_uuid(), fleet_id uuid not null references fleets(id) on delete cascade, unit_number text not null, asset_type text not null default 'truck', vin text, year int, make text, model text, license_plate text, status text not null default 'active', qr_token text not null unique default encode(gen_random_bytes(18),'hex'), created_at timestamptz not null default now());
create table reports(id uuid primary key default gen_random_uuid(), vehicle_id uuid not null references vehicles(id) on delete cascade, submitted_by uuid references profiles(id), description text not null, safety_concern boolean not null default false, created_at timestamptz not null default now());
create table report_photos(id uuid primary key default gen_random_uuid(), report_id uuid not null references reports(id) on delete cascade, storage_path text not null, created_at timestamptz not null default now());
create table tickets(id uuid primary key default gen_random_uuid(), fleet_id uuid not null references fleets(id) on delete cascade, vehicle_id uuid not null references vehicles(id) on delete cascade, report_id uuid references reports(id), assigned_technician uuid references profiles(id), status ticket_status not null default 'open', priority text not null default 'normal', title text not null, description text, opened_at timestamptz not null default now(), completed_at timestamptz);
create table repairs(id uuid primary key default gen_random_uuid(), ticket_id uuid not null unique references tickets(id) on delete cascade, diagnosis text, resolution text, labor_minutes int default 0, labor_cost numeric(12,2) default 0, completed_by uuid references profiles(id), completed_at timestamptz);
create table repair_parts(id uuid primary key default gen_random_uuid(), repair_id uuid not null references repairs(id) on delete cascade, part_name text not null, quantity numeric(10,2) not null default 1, unit_cost numeric(12,2) default 0);
create table repair_photos(id uuid primary key default gen_random_uuid(), repair_id uuid not null references repairs(id) on delete cascade, storage_path text not null, created_at timestamptz not null default now());
create index vehicles_fleet_idx on vehicles(fleet_id); create index reports_vehicle_idx on reports(vehicle_id); create index tickets_fleet_idx on tickets(fleet_id); create index tickets_vehicle_idx on tickets(vehicle_id);

-- Production build should add RLS policies scoped by profile.fleet_id and public QR-report access limited to report creation for a valid vehicle token.
