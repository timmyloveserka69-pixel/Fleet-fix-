import './globals.css';
import Link from 'next/link';

export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="en"><body><header><div className="nav"><Link href="/dashboard" className="brand">FleetFix Digital</Link><nav><Link href="/dashboard">Dashboard</Link><Link href="/vehicles">Vehicles</Link><Link href="/tickets">Tickets</Link></nav></div></header><main>{children}</main></body></html>
}
