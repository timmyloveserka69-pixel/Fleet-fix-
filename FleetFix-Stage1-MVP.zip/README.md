# FleetFix Digital — Stage 1 MVP

B2B SaaS for small/midsize trucking fleets: QR vehicle identity → driver report → manager ticket → technician repair → permanent maintenance history.

## Stack
- Next.js (App Router) + TypeScript
- Supabase (Postgres + Auth)
- Stripe-ready billing hooks
- Vercel-ready deployment

## Stage 1 scope
1. Authentication
2. Fleet dashboard
3. Vehicle/asset records
4. Secure QR vehicle links
5. Driver issue reports + photos
6. Manager tickets + technician assignment
7. Technician diagnosis, parts, labor, photos, completion
8. Permanent maintenance history
9. Email notification hooks

Excluded from Stage 1: AI, GPS/telematics, accounting, native mobile apps, marketplace, advanced preventive maintenance.

## Run
```bash
npm install
cp .env.example .env.local
npm run dev
```

Then open http://localhost:3000.

The SQL schema is in `supabase/schema.sql`. Create a Supabase project, run the SQL, and add the project URL and anon key to `.env.local`.
